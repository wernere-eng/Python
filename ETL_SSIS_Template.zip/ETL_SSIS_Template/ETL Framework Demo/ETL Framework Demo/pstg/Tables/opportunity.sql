﻿CREATE TABLE [pstg].[opportunity] (
    [ctl_in4_id_job_run]      INT          NOT NULL,
    [ctl_in4_id_job_step_run] INT          NOT NULL,
    [ctl_dtm_row_insert]      DATETIME     DEFAULT (getdate()) NOT NULL,
    [vbn_hsh_md5_row]         AS           (CONVERT([varbinary](16),hashbytes('MD5',(((((((((((((isnull(CONVERT([varchar](10),[in4_id_opportunity]),'')+'|')+isnull(CONVERT([varchar](100),[vcr_nm_company]),''))+'|')+isnull(CONVERT([varchar](20),[in4_crncy_total_value]),''))+'|')+isnull(CONVERT([varchar](20),[in4_crncy_forecast]),''))+'|')+isnull(CONVERT([varchar](20),[in4_crncy_potential]),''))+'|')+isnull(CONVERT([varchar](20),[in4_crncy_received]),''))+'|')+isnull(CONVERT([varchar](4),[in2_yr_start]),''))+'|')+isnull(CONVERT([varchar](50),[vcr_nm_region]),'')))),
    [in4_id_opportunity]      INT          NOT NULL,
    [vcr_nm_company]          VARCHAR (50) NULL,
    [in4_crncy_total_value]   INT          NOT NULL,
    [in4_crncy_forecast]      INT          NULL,
    [in4_crncy_potential]     INT          NULL,
    [in4_crncy_received]      INT          NULL,
    [in2_yr_start]            SMALLINT     NULL,
    [vcr_nm_region]           VARCHAR (50) NULL,
    CONSTRAINT [pk__opportunity] PRIMARY KEY CLUSTERED ([in4_id_opportunity] ASC)
);

