﻿CREATE TABLE [pstg].[null_list] (
    [ctl_in4_id_job_run]      INT          NOT NULL,
    [ctl_in4_id_job_step_run] INT          NOT NULL,
    [ctl_dtm_row_insert]      DATETIME     DEFAULT (getdate()) NOT NULL,
    [vbn_hsh_md5_row]         AS           (CONVERT([varbinary](16),hashbytes('MD5',(((((isnull(CONVERT([varchar](10),[in4_id_student]),'')+'|')+isnull(CONVERT([varchar](10),[in4_cd_crn]),''))+'|')+isnull(CONVERT([varchar](10),[dte_registration],(112)),'19000101'))+'|')+isnull(CONVERT([varchar](10),[vcr_cd_resulted]),'')))),
    [in4_id_student]          INT          NOT NULL,
    [in4_cd_crn]              INT          NOT NULL,
    [dte_registration]        DATE         NULL,
    [vcr_cd_resulted]         VARCHAR (10) NULL,
    CONSTRAINT [pk__null_list] PRIMARY KEY CLUSTERED ([in4_id_student] ASC, [in4_cd_crn] ASC),
    CONSTRAINT [fk__null_list__student__in4_id_student] FOREIGN KEY ([in4_id_student]) REFERENCES [pstg].[student] ([in4_id_student])
);

