﻿CREATE TABLE [pstg].[student] (
    [ctl_in4_id_job_run]      INT            NOT NULL,
    [ctl_in4_id_job_step_run] INT            NOT NULL,
    [ctl_dtm_row_insert]      DATETIME       DEFAULT (getdate()) NOT NULL,
    [vbn_hsh_md5_row]         AS             (CONVERT([varbinary](16),hashbytes('MD5',(((((isnull(CONVERT([varchar](10),[in4_id_student]),'')+'|')+isnull(CONVERT([varchar](10),[in4_id_opportunity]),''))+'|')+isnull(CONVERT([varchar](1000),[vcr_txt_crn_list]),''))+'|')+isnull(CONVERT([varchar](10),[vcr_id_programme]),'')))),
    [in4_id_student]          INT            NOT NULL,
    [in4_id_opportunity]      INT            NULL,
    [vcr_txt_crn_list]        VARCHAR (1000) NOT NULL,
    [vcr_id_programme]        VARCHAR (10)   NOT NULL,
    CONSTRAINT [pk__student] PRIMARY KEY CLUSTERED ([in4_id_student] ASC),
    CONSTRAINT [fk__student__opportunity__in4_id_opportunity] FOREIGN KEY ([in4_id_opportunity]) REFERENCES [pstg].[opportunity] ([in4_id_opportunity])
);

