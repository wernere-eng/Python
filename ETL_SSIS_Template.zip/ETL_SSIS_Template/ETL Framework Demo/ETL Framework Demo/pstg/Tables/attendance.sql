﻿CREATE TABLE [pstg].[attendance] (
    [ctl_in4_id_job_run]           INT             NOT NULL,
    [ctl_in4_id_job_step_run]      INT             NOT NULL,
    [ctl_dtm_row_insert]           DATETIME        DEFAULT (getdate()) NOT NULL,
    [vbn_hsh_md5_row]              AS              (CONVERT([varbinary](16),hashbytes('MD5',(((((((((((((((isnull(CONVERT([varchar](10),[in4_id_student]),'')+'|')+isnull(CONVERT([varchar](10),[in4_cd_crn]),''))+'|')+isnull(CONVERT([varchar](10),[dte_attended],(103)),''))+'|')+isnull(CONVERT([varchar](10),[num_hrs_attended]),''))+'|')+isnull(CONVERT([varchar](10),[num_hrs_contact]),''))+'|')+isnull(CONVERT([varchar](10),[dte_crn_start],(103)),''))+'|')+isnull(CONVERT([varchar](10),[dte_crn_end],(103)),''))+'|')+isnull(CONVERT([varchar](1000),[vcr_txt_national_course_desc]),''))+'|')+isnull(CONVERT([varchar](1000),[vcr_txt_programme_desc]),'')))),
    [in4_id_student]               INT             NOT NULL,
    [in4_cd_crn]                   INT             NOT NULL,
    [dte_attended]                 DATE            NOT NULL,
    [num_hrs_attended]             NUMERIC (18, 2) NOT NULL,
    [num_hrs_contact]              NUMERIC (18)    NOT NULL,
    [dte_crn_start]                DATE            NOT NULL,
    [dte_crn_end]                  DATE            NOT NULL,
    [vcr_txt_national_course_desc] VARCHAR (1000)  NOT NULL,
    [vcr_txt_programme_desc]       VARCHAR (1000)  NOT NULL,
    CONSTRAINT [pk__attendance] PRIMARY KEY CLUSTERED ([in4_id_student] ASC, [in4_cd_crn] ASC, [dte_attended] ASC),
    CONSTRAINT [fk__attendance__student__in4_id_student] FOREIGN KEY ([in4_id_student]) REFERENCES [pstg].[student] ([in4_id_student])
);

