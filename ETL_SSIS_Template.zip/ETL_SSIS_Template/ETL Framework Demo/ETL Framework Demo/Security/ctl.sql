﻿CREATE SCHEMA [ctl]
    AUTHORIZATION [dbo];

