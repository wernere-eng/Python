﻿CREATE SCHEMA [ingst]
    AUTHORIZATION [dbo];

