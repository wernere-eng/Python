﻿CREATE SCHEMA [pstg]
    AUTHORIZATION [dbo];

