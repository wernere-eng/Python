﻿CREATE TABLE [ingst].[null_list] (
    [ctl_in4_num_row]         BIGINT         IDENTITY (1, 1) NOT NULL,
    [ctl_in4_id_job_run]      INT            NOT NULL,
    [ctl_in4_id_job_step_run] INT            NOT NULL,
    [ctl_dtm_row_insert]      DATETIME       DEFAULT (getdate()) NOT NULL,
    [vbn_hsh_md5_row]         AS             (CONVERT([varbinary](16),hashbytes('MD5',(((((isnull(CONVERT([varchar](10),[STUDENT_ID]),'')+'|')+isnull(CONVERT([varchar](10),[CRN]),''))+'|')+isnull(CONVERT([varchar](10),CONVERT([date],[REGISTRATION_DATE],(101)),(112)),''))+'|')+isnull(CONVERT([varchar](10),[RESULTED]),'')))),
    [TERM_CODE]               VARCHAR (1000) NULL,
    [CRN]                     VARCHAR (1000) NULL,
    [DEPARTMENT]              VARCHAR (1000) NULL,
    [CAMPUS_CODE]             VARCHAR (1000) NULL,
    [PROGRAM]                 VARCHAR (1000) NULL,
    [PROGRAM_DESC]            VARCHAR (1000) NULL,
    [CONTACT_HOURS]           VARCHAR (1000) NULL,
    [STUDENT_ID]              VARCHAR (1000) NULL,
    [LAST_NAME]               VARCHAR (1000) NULL,
    [FIRST_NAME]              VARCHAR (1000) NULL,
    [REGISTRATION_DATE]       VARCHAR (1000) NULL,
    [RESULTED]                VARCHAR (1000) NULL,
    PRIMARY KEY CLUSTERED ([ctl_in4_num_row] ASC)
);

