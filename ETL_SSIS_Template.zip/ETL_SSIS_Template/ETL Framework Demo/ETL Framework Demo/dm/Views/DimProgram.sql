﻿CREATE VIEW dm.DimProgram AS
SELECT	ROW_NUMBER()OVER(
			ORDER BY	p.Program, p.Program_title
		) AS ProgramSK
		, p.Program AS ProgramID
		, p.Program_title AS ProgramTitle
FROM	(	SELECT	s.Program, s.Program_title
			FROM	ingst.student_data s
			GROUP BY
					s.Program, s.Program_title
		) p
;