﻿CREATE VIEW dm.FactOpportunity AS
SELECT	o.in4_id_opportunity AS OpportunitySK
		, ds.StudentSK
		, dr.RegionSK
		, dc.CompanySK
		, dd.DateKey AS DateSK
		-- Measures
		, CAST(o.in4_crncy_total_value AS MONEY) AS TotalValue
		, CAST(COALESCE(o.in4_crncy_forecast, 0) AS MONEY) AS ForcastAmount
		, CAST(o.in4_crncy_received AS MONEY) AS ReceivedAmount
FROM	pstg.opportunity o
		LEFT JOIN pstg.student s
			ON o.in4_id_opportunity = s.in4_id_opportunity
		INNER JOIN dm.DimStudent ds
			ON s.in4_id_student = ds.StudentID
		--
		LEFT JOIN dm.DimRegion dr
			ON o.vcr_nm_region = dr.Region
		left join dm.DimCompany dc
			on o.vcr_nm_company = dc.CompanyName
		left join dm.DimDate dd
			on cast(o.in2_yr_start as varchar(4)) + '01' + '01' = dd.DateKey
;