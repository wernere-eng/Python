﻿CREATE VIEW dm.DimRegion AS
SELECT	ROW_NUMBER()OVER(ORDER BY a.Region ASC) AS RegionSK
		, Region
FROM	(	SELECT	COALESCE(vcr_nm_region, 'Not Available') AS Region
			FROM	pstg.opportunity o
			GROUP BY vcr_nm_region
		) a
union all
select -1, 'None'
;
