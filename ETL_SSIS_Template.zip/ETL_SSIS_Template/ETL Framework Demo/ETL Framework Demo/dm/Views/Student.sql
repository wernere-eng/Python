﻿CREATE VIEW dm.Student AS
SELECT	StudentSK
		, StudentID
		, FirstName
		, LastName
		, pcode AS PostCode
		, state AS [State]
		, city AS City
FROM	(
			SELECT	ROW_NUMBER()OVER(ORDER BY a.in4_id_student ASC) StudentSK
					, a.in4_id_student AS StudentID
					, a.FirstName
					, a.LastName
					, s.pcode
					, s.state
					, s.city
					, ROW_NUMBER()over(partition by a.in4_id_student order by a.in4_id_student asc) in4_row_num
			FROM	(	SELECT	s.in4_id_student
								, COALESCE(a.FIRST_NAME, 'Not Available') AS FirstName
								, COALESCE(a.LAST_NAME, 'Not Available') AS LastName
						FROM	pstg.student s
								LEFT JOIN ingst.attendance a
									ON s.in4_id_student = CAST(a.STUDENT_ID AS INT)
						GROUP BY s.in4_id_student
								, a.FIRST_NAME
								, a.LAST_NAME
					) a
					inner join ingst.student_data s
						on a.in4_id_student = s.Student_id
		) a
where a.in4_row_num = 1
union all
select -1
		, -1
		, 'None'
		, 'None'
		, '' AS PostCode
		, '' AS [State]
		, '' AS City
;