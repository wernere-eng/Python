﻿CREATE VIEW dm.FactAttendance AS
SELECT	ds.StudentSK
		, dc.CrnSK
		, dd.DateKey AS DateSK
		, dp.ProgramSK
		, COALESCE(dr.ResultSK, -1) AS ResultSK
		, CAST (a.HOURS_ATTENDED AS NUMERIC (18, 2)) AS HoursAttended
		--select count(1)
FROM	ingst.attendance a--96
		LEFT JOIN dm.DimStudent ds
			ON CAST(a.STUDENT_ID AS INT) = ds.StudentID--96
		LEFT JOIN dm.DimProgram dp
			ON a.PROGRAMME = dp.ProgramID--96
		LEFT JOIN dm.DimCrn dc
			ON a.CRN = dc.CRN--96
		LEFT JOIN pstg.null_list n
			ON CAST(a.STUDENT_ID AS INT) = n.in4_id_student
			AND CAST(a.CRN AS INT) = n.in4_cd_crn--96
		left join dm.DimResult dr
			on n.vcr_cd_resulted = dr.Result--96
		left join dm.DimDate dd
			on CONVERT(date, a.ATTENDANCE_DATE, 103) = dd.Date
;