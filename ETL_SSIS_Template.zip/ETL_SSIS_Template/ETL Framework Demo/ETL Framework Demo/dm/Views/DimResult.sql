﻿CREATE view dm.DimResult as
select	ROW_NUMBER()over(order by r.vcr_cd_resulted) as ResultSK
		, r.vcr_cd_resulted as Result
from	(
select	a.vcr_cd_resulted
from	pstg.null_list a
where	a.vcr_cd_resulted != ''
group by a.vcr_cd_resulted
) r
union all
select	-1, 'None'
;
