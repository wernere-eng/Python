﻿CREATE VIEW dm.DimCrn AS
SELECT	ROW_NUMBER()OVER(
			ORDER BY	c.in4_cd_crn ASC
		) AS CrnSK
		, c.in4_cd_crn AS CRN
		, c.dte_crn_start AS CrnStartDate
		, c.dte_crn_end AS CrnEndDate
		, c.num_hrs_contact AS ContactHours
FROM	(	SELECT	a.in4_cd_crn, a.dte_crn_start, a.dte_crn_end, a.num_hrs_contact
					, ROW_NUMBER()OVER(partition by a.in4_cd_crn order by a.in4_cd_crn) as row_num
			FROM	pstg.attendance a
			GROUP BY
					a.in4_cd_crn, a.dte_crn_start, a.dte_crn_end, a.num_hrs_contact
		) c
where	row_num = 1
;