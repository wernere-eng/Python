﻿CREATE View dm.DimCompany AS
select	ROW_NUMBER()OVER(
			order by c.vcr_nm_company
		) as CompanySK
		, c.vcr_nm_company as CompanyName
FROM	(
			select	o.vcr_nm_company
			from	pstg.opportunity o
			where	o.vcr_nm_company is not null
			GROUP BY o.vcr_nm_company
		) c
union all 
select -1, 'None'
;