﻿CREATE TABLE [dm].[DimDate] (
    [DateKey]       INT       NOT NULL,
    [Date]          DATETIME  NOT NULL,
    [Day]           CHAR (10) NULL,
    [DayOfWeek]     SMALLINT  NULL,
    [DayOfMonth]    SMALLINT  NULL,
    [DayOfYear]     SMALLINT  NULL,
    [PreviousDay]   DATETIME  NULL,
    [NextDay]       DATETIME  NULL,
    [WeekOfYear]    SMALLINT  NULL,
    [Month]         CHAR (10) NULL,
    [MonthOfYear]   SMALLINT  NULL,
    [QuarterOfYear] SMALLINT  NULL,
    [Year]          INT       NULL
);

