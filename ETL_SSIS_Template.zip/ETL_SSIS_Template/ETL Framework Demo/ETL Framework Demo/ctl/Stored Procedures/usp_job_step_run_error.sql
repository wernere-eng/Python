﻿/*****************************************************************************************
 *
 * Author:		Matthew D Signor | Melbourne Australia
 * Date:		2016-05-07
 *
 * Name:		Job Step Run Error
 * Purpose:		To update the SCHEMA.TABLE.COLUMN [ctl].[job_step_run].[in4_cde_error] and
 *				[ctl].[job_step_run].[vcr_txt_error_description] with details of the 
 *				error causing a respective Job Step Run to FAIL.
 *
 * Dependents:
 *	SCHEMA.PROCEDURE:[ctl].[usp_job_step_run_error] depends on 
 *	SCHEMA.TABLE:[ctl].[job_step_run]
 *
 * Description:
 *	This PROCEDURE has 1 behaviour:
 *		1) Update the Job Step Run table with error details.
 *
 * Conditions:
 *
 * Exceptions:
 *	None
 *
 * Input Parameters:
 *	INT:in4_id_job_run
 * VARCHAR:vcr_nm_etl_package
 *	INT:in4_cde_error
 *	VARCHAR:vcr_txt_error_description
 *
 * Output Parameters:
 *	None
 *
 * History:
 * Ver	Date		Contributer				Comment
 * ----	-----------	-----------------------	----------------------------------------------
 * 0001	2016-05-07	Matthew D Signor		Initial
 *
 *****************************************************************************************
 */
create procedure ctl.usp_job_step_run_error(
	@__in4_id_job_run INT = NULL
	, @__vcr_nm_etl_package VARCHAR(1000) = NULL
	, @__in4_cde_error INT = NULL
	, @__vcr_txt_error_description VARCHAR(4000) = NULL
) AS BEGIN
	/**
	 * DECLARATIONS
	 * ****************************************
	 */
	DECLARE @error_code INT
			, @error_message NVARCHAR(2048)
			, @in1_cde_state TINYINT
			, @in4_id_job_step_run INT
			, @in1_cde_status TINYINT;

	/** 
	 * INTIALISATIONS
	 * ****************************************
	 */


	/**
	 * MAIN
	 * ****************************************
	 */
	BEGIN TRY
		/**
		 * INITIALISATIONS
		 */
		 BEGIN TRANSACTION;

			-- ---------------------------------------------------------------------------
			-- Get job step
			-- ---------------------------------------------------------------------------
			SELECT	@in4_id_job_step_run = jsr.in4_id_job_step_run
					, @in1_cde_status = jsr.in1_cde_status
			FROM	ctl.job_step_run jsr
					INNER JOIN ctl.job_step js
						ON jsr.in4_id_job_step = js.in4_id_job_step
					INNER JOIN ctl.job_run jr
						ON jsr.in4_id_job_run = jr.in4_id_job_run
			WHERE	jr.in4_id_job_run = @__in4_id_job_run
					AND js.vcr_nm_etl_package = @__vcr_nm_etl_package;

			-- ---------------------------------------------------------------------------
			-- Update with error
			-- ---------------------------------------------------------------------------
			UPDATE	[ctl].job_step_run SET
					in1_cde_status = 3
					, dtm_end = CURRENT_TIMESTAMP
					, in4_cde_error = @__in4_cde_error
					, vcr_txt_error_description = @__vcr_txt_error_description
			WHERE	in4_id_job_step_run = @in4_id_job_step_run;

		 COMMIT TRANSACTION;
	END TRY
	/**
	 * ERROR HANDLING
	 * ****************************************
	 */
	BEGIN CATCH	
		/**
		 * Test XACT_STATE for 0, 1, or -1.
		 * If 1, the transaction is committable.
		 * If -1, the transaction is uncommittable and should 
		 *     be rolled back.
		 * XACT_STATE = 0 means there is no transaction and
		 *     a commit or rollback operation would generate an error.
		 */

		-- Test whether the transaction is uncommittable.
		IF (XACT_STATE()) <> 0 BEGIN				
			ROLLBACK TRANSACTION;				
		END;

		THROW;
	END CATCH

END
