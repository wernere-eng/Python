﻿/*****************************************************************************************
 *
 * Author:		Matthew D Signor | Melbourne Australia
 * Date:		2016-05-07
 *
 * Name:		Job Step Run Finalise
 * Purpose:		To update the SCHEMA.TABLE.COLUMN [ctl].[job_step_run].[in4_cde_error] and
 *				[ctl].[job_step_run].[vcr_txt_error_description] with details of 
 *				execution. NOTE that this PROCEDURE will set a SUCCESS status to the 
 *				Job Step Run.
 *
 * Dependents:
 *	SCHEMA.PROCEDURE:[ctl].[usp_job_step_run_initialise] depends on 
 *	SCHEMA.TABLE:[ctl].[job_step_run]
 *
 * Description:
 *	This PROCEDURE has 2 behaviours:
 *		1) Update the Job Step Run table with Status, Dates and Row Counts.
 *		2) Do nothing
 *
 *	If this PROCEDURE is executed then it means that the Job Step Run completed sucessfully.
 *	
 *	DO NOT call this PROCEDURE if the ETL job did NOT complete successfully because it 
 *	sets the error fields. Instead call Job Step Run Error! 
 *	NOTE: Calling Job Step Run Error should be handled by an Event Handler in the SSIS package.
 *
 * Conditions:
 *
 * Exceptions:
 *	None
 *
 * Input Parameters:
 *	INT:in4_id_job_run
 *	VARCHAR:vcr_nm_etl_package
 *	TINYINT:flg_executed
 *	INT:in4_num_rows_selected
 *	INT:in4_num_rows_discarded
 *	INT:in4_num_rows_updated
 *	INT:in4_num_rows_inserted
 *	INT:in4_num_rows_deleted
 *
 * Output Parameters:
 *	None
 *
 * History:
 * Ver	Date		Contributer				Comment
 * ----	-----------	-----------------------	----------------------------------------------
 * 0001	2016-05-07	Matthew D Signor		Initial
 *
 *****************************************************************************************
 */
CREATE procedure ctl.usp_job_step_run_finalise(
	@__in4_id_job_run INT = NULL
	, @__vcr_nm_etl_package VARCHAR(1000) = NULL
	, @__flg_executed TINYINT = NULL
	, @__in4_num_rows_selected INT = 0
	, @__in4_num_rows_discarded INT = 0
	, @__in4_num_rows_updated INT = 0
	, @__in4_num_rows_inserted INT = 0
	, @__in4_num_rows_deleted INT = 0
) AS BEGIN
	/**
	 * DECLARATIONS
	 * ****************************************
	 */
	DECLARE @error_code INT
			, @error_message NVARCHAR(2048)
			, @in1_cde_state TINYINT
			, @in4_id_job_step_run INT
			, @in1_cde_status TINYINT
			;

	/** 
	 * INTIALISATIONS
	 * ****************************************
	 */


	/**
	 * MAIN
	 * ****************************************
	 */

	BEGIN TRY
		/**
		 * INITIALISATIONS
		 */
		 BEGIN TRANSACTION;

			-- ---------------------------------------------------------------------------
			-- Get job step
			-- ---------------------------------------------------------------------------
			SELECT	@in4_id_job_step_run = jsr.in4_id_job_step_run
					, @in1_cde_status = jsr.in1_cde_status
			FROM	ctl.job_step_run jsr
					INNER JOIN ctl.job_step js
						ON jsr.in4_id_job_step = js.in4_id_job_step
					INNER JOIN ctl.job_run jr
						ON jsr.in4_id_job_run = jr.in4_id_job_run
			WHERE	jr.in4_id_job_run = @__in4_id_job_run
					AND js.vcr_nm_etl_package = @__vcr_nm_etl_package;

			-- ---------------------------------------------------------------------------
			-- Get job step
			-- ---------------------------------------------------------------------------
			IF @__flg_executed = 1
			BEGIN

				UPDATE	[ctl].job_step_run SET
						in1_cde_status = 0
						, dtm_end = CURRENT_TIMESTAMP
						, in4_cde_error = 0
						, vcr_txt_error_description = NULL
						, in4_num_rows_selected = @__in4_num_rows_selected
						, in4_num_rows_discarded = @__in4_num_rows_discarded
						, in4_num_rows_updated = @__in4_num_rows_updated
						, in4_num_rows_inserted = @__in4_num_rows_inserted
						, in4_num_rows_deleted = @__in4_num_rows_deleted
				WHERE	in4_id_job_step_run = @in4_id_job_step_run;

			END

		 COMMIT TRANSACTION;
	END TRY
	/**
	 * ERROR HANDLING
	 * ****************************************
	 */
	BEGIN CATCH	
		/**
		 * Test XACT_STATE for 0, 1, or -1.
		 * If 1, the transaction is committable.
		 * If -1, the transaction is uncommittable and should 
		 *     be rolled back.
		 * XACT_STATE = 0 means there is no transaction and
		 *     a commit or rollback operation would generate an error.
		 */

		-- Test whether the transaction is uncommittable.
		IF (XACT_STATE()) <> 0 BEGIN				
			ROLLBACK TRANSACTION;				
		END;

		THROW;
	END CATCH

END
