﻿/*****************************************************************************************
 *
 * Author:		Matthew D Signor | Melbourne Australia
 * Date:		2016-05-07
 *
 * Name:		Job Run Initialise
 * Purpose:		To determine if a Job Run is to be CREATED and EXECUTED; or, 
 *				an existing Job Run should EXECUTE.
 *
 * Dependents:
 *	SCHEMA.TABLE:[ctl].[job_run] depends on SCHEMA.TABLE:[ctl].[job]
 *
 * Description:
 *	This PROCEDURE has 3 behaviours:
 *		1) CREATE and EXECUTE a new Job Run
 *		2) EXECUTE and existing Job Run
 *		3) THROW an EXCEPTION because there is a Job Run currently EXECUTING.
 *
 * Conditions:
 *	- There must be a Job defined in the TABLE [ctl].[job] for the INPUT PARAMETER
 *		Job ID.
 *	- The defined Job must be enabled.
 *	- To execute a job a row will be entered into the Job Run table by this PROCEDURE.
 *	- The Job Run table will contain no ROWS if a job has never been run.
 *	- The field Job Run Status [in1_cd_status] has the following values | meaning:
 *		0 | Job Run Successfully Completed
 *		1 | Job Run Awaiting Execution
 *		2 | Job Run Executing
 *		3 | Job Run Failed; or, Job Run Erroneous.
 *	- A new Job Run can only be created if the Status of the last Job Run in the TABLE
 *		is 0.
 *	- The last Job Run will have the highest Job Run ID.
 *	- When a Job Run is created it's status will be set to 1.
 *	- A Job Run whose status is 2 will NOT be executed.
 *	- Job's with the status 1 or 3 will be executed.
 *	- Jobs that are NOT enabled will execute successfully however, no Job Run will be
 *		CREATED and NO Job Steps will be executed.
 *
 * Exceptions:
 *	250000|Job Run is already Executing
 *
 * Input Parameters:
 *	INT:in4_id_job
 *
 * Output Parameters:
 *	INT:in4_id_job_run
 *
 * History:
 * Ver	Date		Contributer				Comment
 * ----	-----------	-----------------------	----------------------------------------------
 * 0001	2016-05-07	Matthew D Signor		Initial
 *
 *****************************************************************************************
 */
CREATE procedure ctl.usp_job_run_instantiate(
	@__in4_id_job INT = NULL
	, @__in4_id_job_run INT = NULL OUTPUT
) AS BEGIN
	/**
	 * DECLARATIONS
	 * ****************************************
	 */
	DECLARE @error_code INT
			, @error_message NVARCHAR(2048)
			, @in1_cde_state TINYINT
			, @in4_id_job_run INT
			, @in1_cde_status TINYINT
			, @bit_flg_job_run_complete BIT;

	/** 
	 * INTIALISATIONS
	 * ****************************************
	 */
	SET @in1_cde_status = NULL;

	/**
	 * MAIN
	 * ****************************************
	 */

	BEGIN TRY
		/**
		 * INITIALISATIONS
		 */
		 BEGIN TRANSACTION;

			-- ---------------------------------------------------------------------------
			-- Get latest job run | will return null on first ever run
			-- ---------------------------------------------------------------------------
			SELECT	@in4_id_job_run = MAX(in4_id_job_run)
			FROM	ctl.job_run jr
			WHERE	jr.in4_id_job = @__in4_id_job;

			-- ---------------------------------------------------------------------------
			-- Set return value
			-- ---------------------------------------------------------------------------
			SET @__in4_id_job_run = @in4_id_job_run;

			-- ---------------------------------------------------------------------------
			-- Get the status of the latest job run | will return null on the first run
			-- ---------------------------------------------------------------------------
			SELECT	@in1_cde_status = in1_cde_status
			FROM	ctl.job_run jr
			WHERE	in4_id_job_run = @in4_id_job_run;	

			-- ---------------------------------------------------------------------------
			-- Check if the latest job run is still running
			-- ---------------------------------------------------------------------------
			IF ISNULL(@in1_cde_status, 0) = 2 BEGIN

				SET @error_code = 250000;
				SET @error_message = 'Based on the Job Status in the Job Run table, this job is already running';

				THROW @error_code, @error_message, @in1_cde_state;

			END

			-- ---------------------------------------------------------------------------
			-- Only create a new Job Run if the last Job Run executed without problems
			-- ---------------------------------------------------------------------------
			IF ISNULL(@in1_cde_status, 0) = 0 BEGIN

				--- ----------------------------------------------------------------------
				-- Create new job run
				-- -----------------------------------------------------------------------
				INSERT INTO ctl.job_run(
					in4_id_job
				) VALUES (@__in4_id_job);

				--- ----------------------------------------------------------------------
				-- Get identity insert value
				-- -----------------------------------------------------------------------
				SELECT @in4_id_job_run = SCOPE_IDENTITY();

				-- -----------------------------------------------------------------------
				-- Set return value
				-- -----------------------------------------------------------------------
				SET @__in4_id_job_run = @in4_id_job_run;

				-- -----------------------------------------------------------------------
				-- Create new job run instance
				-- -----------------------------------------------------------------------
				INSERT INTO ctl.job_step_run(
					in4_id_job_run, in4_id_job_step
				)
				SELECT	jr.in4_id_job_run, js.in4_id_job_step
				FROM	ctl.job_step js
						INNER JOIN ctl.job_run jr
							ON js.in4_id_job = jr.in4_id_job
				WHERE	jr.in4_id_job_run = @in4_id_job_run
						AND js.bit_flg_enabled = 1;

			END

		 COMMIT TRANSACTION;
	END TRY
	/**
	 * ERROR HANDLING
	 * ****************************************
	 */
	BEGIN CATCH	
		/**
		 * Test XACT_STATE for 0, 1, or -1.
		 * If 1, the transaction is committable.
		 * If -1, the transaction is uncommittable and should 
		 *     be rolled back.
		 * XACT_STATE = 0 means there is no transaction and
		 *     a commit or rollback operation would generate an error.
		 */

		-- Test whether the transaction is uncommittable.
		IF (XACT_STATE()) <> 0 BEGIN				
			ROLLBACK TRANSACTION;				
		END;

		THROW;
	END CATCH

END




BEGIN TRANSACTION;

	-- ---------------------------------------------------------------------------
	-- Get latest job run | will return null on first ever run
	-- ---------------------------------------------------------------------------
	SELECT	@in4_id_job_run = MAX(in4_id_job_run)
	FROM	ctl.job_run jr
	WHERE	jr.in4_id_job = @__in4_id_job;

	-- ---------------------------------------------------------------------------
	-- Set return value
	-- ---------------------------------------------------------------------------
	SET @__in4_id_job_run = @in4_id_job_run;

	-- ---------------------------------------------------------------------------
	-- Get the status of the latest job run | will return null on the first run
	-- ---------------------------------------------------------------------------
	SELECT	@in1_cde_status = in1_cde_status
	FROM	ctl.job_run jr
	WHERE	in4_id_job_run = @in4_id_job_run;	

	-- ---------------------------------------------------------------------------
	-- Check if the latest job run is still running
	-- ---------------------------------------------------------------------------
	IF ISNULL(@in1_cde_status, 0) = 2 BEGIN

		SET @error_code = 250000;
		SET @error_message = 'Based on the Job Status in the Job Run table, this job is already running';

		THROW @error_code, @error_message, @in1_cde_state;

	END