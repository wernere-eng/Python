﻿/*****************************************************************************************
 *
 * Author:		Matthew D Signor | Melbourne Australia
 * Date:		2016-05-07
 *
 * Name:		Job Run Finalise
 * Purpose:		To update the SCHEMA.TABLE [ctl].[job_run] Status field and dates.
 *
 * Dependents:
 *	SCHEMA.TABLE:[ctl].[job_run] depends on SCHEMA.TABLE:[ctl].[job]
 *
 * Description:
 *	This PROCEDURE has 1 behaviour:
 *		1) Update provided Job Run with Status values and dates.
 *
 * Conditions:
 *	Job Step Run Status values:
 *		0 | Job Step Run completed successfully
 *		1 | Job Step Run awaiting EXECUTION
 *		2 | Job Step Run EXECUTING
 *		3 | Job Step Run FAILED; or, Job Run Step is Erroneous
 *
 * Exceptions:
 *	None
 *
 * Input Parameters:
 *	INT:in4_id_job_run
 *
 * Output Parameters:
 *	None
 *
 * History:
 * Ver	Date		Contributer				Comment
 * ----	-----------	-----------------------	----------------------------------------------
 * 0001	2016-05-07	Matthew D Signor		Initial
 *
 *****************************************************************************************
 */
CREATE procedure ctl.usp_job_run_finalise(
	@__in4_id_job_run INT = NULL
) AS BEGIN
/**
	 * DECLARATIONS
	 * ****************************************
	 */
	DECLARE @in1_cde_status TINYINT;

	/**
	 * MAIN
	 * ****************************************
	 */

	BEGIN TRY
		/**
		 * INITIALISATIONS
		 */
		 BEGIN TRANSACTION;

			-- ---------------------------------------------------------------------------
			-- Get the MAX status value of all Job Step Runs
			-- ---------------------------------------------------------------------------
			SELECT	@in1_cde_status = MAX(in1_cde_status)
			FROM	ctl.job_step_run jsr
			WHERE	in4_id_job_run = @__in4_id_job_run;

			-- ---------------------------------------------------------------------------
			-- Update job run table
			-- ---------------------------------------------------------------------------
			UPDATE	ctl.job_run SET 
					in1_cde_status = @in1_cde_status
					, dtm_updated = CURRENT_TIMESTAMP
					, dtm_end = CURRENT_TIMESTAMP
			WHERE	in4_id_job_run = @__in4_id_job_run;

		 COMMIT TRANSACTION;
	END TRY
	/**
	 * ERROR HANDLING
	 * ****************************************
	 */
	BEGIN CATCH	
		/**
		 * Test XACT_STATE for 0, 1, or -1.
		 * If 1, the transaction is committable.
		 * If -1, the transaction is uncommittable and should 
		 *     be rolled back.
		 * XACT_STATE = 0 means there is no transaction and
		 *     a commit or rollback operation would generate an error.
		 */

		-- Test whether the transaction is uncommittable.
		IF (XACT_STATE()) <> 0 BEGIN				
			ROLLBACK TRANSACTION;				
		END;

		THROW;
	END CATCH

END
