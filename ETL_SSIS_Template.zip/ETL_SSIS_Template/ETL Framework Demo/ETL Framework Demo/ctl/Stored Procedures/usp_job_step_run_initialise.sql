﻿/*****************************************************************************************
 *
 * Author:		Matthew D Signor | Melbourne Australia
 * Date:		2016-05-07
 *
 * Name:		Job Run Initialise
 * Purpose:		To determine if a Job Step Run is to be EXECUTED; or, 
 *				by-passed.
 *
 * Dependents:
 *	SCHEMA.PROCEDURE:[ctl].[job_step_run_initialise] depends on 
 *	SCHEMA.TABLE:[ctl].[job_ste_run]
 *
 * Description:
 *	This PROCEDURE has 2 behaviours:
 *		1) Set status of provided Job Step Run to EXECUTING and return Job Step Ready Flag.
 *		2) Do Nothing if the Job Step Run has already completed successfully or is 
 *			currently EXECUTING.
 *
 * Conditions:
 *	Job Step Run Status values:
 *		0 | Job Step Run completed successfully
 *		1 | Job Step Run awaiting EXECUTION
 *		2 | Job Step Run EXECUTING
 *		3 | Job Step Run FAILED; or, Job Run Step is Erroneous
 *
 * Exceptions:
 *	None
 *
 * Input Parameters:
 *	INT:in4_id_job_run
 *	VARCHAR:vcr_nm_etl_package
 *
 * Output Parameters:
 *	TINYINT:in1_flg_job_step_ready
 *	INT:in4_id_job_step_run
 *
 * History:
 * Ver	Date		Contributer				Comment
 * ----	-----------	-----------------------	----------------------------------------------
 * 0001	2016-05-07	Matthew D Signor		Initial
 *
 *****************************************************************************************
 */
CREATE procedure ctl.usp_job_step_run_initialise(
	@__in4_id_job_run INT = NULL
	, @__vcr_nm_etl_package VARCHAR(1000) = NULL
	, @__in1_flg_job_step_ready TINYINT = 0 OUTPUT
	, @__in4_id_job_step_run INT = NULL OUTPUT
) AS BEGIN
	/**
	 * DECLARATIONS
	 * ****************************************
	 */
	DECLARE @error_code INT
			, @error_message NVARCHAR(2048)
			, @in1_cde_state TINYINT
			, @in4_id_job_step_run INT
			, @in1_cde_status TINYINT;

	/** 
	 * INTIALISATIONS
	 * ****************************************
	 */
	SET @__in1_flg_job_step_ready = 0;

	/**
	 * MAIN
	 * ****************************************
	 */

	BEGIN TRY
		/**
		 * INITIALISATIONS
		 */
		 BEGIN TRANSACTION;

			-- ---------------------------------------------------------------------------
			-- Get job step
			-- ---------------------------------------------------------------------------
			SELECT	@in4_id_job_step_run = jsr.in4_id_job_step_run
					, @in1_cde_status = jsr.in1_cde_status
			FROM	ctl.job_step_run jsr
					INNER JOIN ctl.job_step js
						ON jsr.in4_id_job_step = js.in4_id_job_step
					INNER JOIN ctl.job_run jr
						ON jsr.in4_id_job_run = jr.in4_id_job_run
			WHERE	jr.in4_id_job_run = @__in4_id_job_run
					AND js.vcr_nm_etl_package = @__vcr_nm_etl_package;

			SET @__in4_id_job_step_run = @in4_id_job_step_run;

			--print @in4_id_job_step_run;

			--print @in1_cde_status;
			-- ---------------------------------------------------------------------------
			-- Update status to running if its not already running or finished
			-- ---------------------------------------------------------------------------
			IF @in1_cde_status NOT IN (0, 2)
			BEGIN

				UPDATE ctl.job_step_run SET
						in1_cde_status = 2
						, dtm_start = CURRENT_TIMESTAMP
				WHERE	in4_id_job_step_run = @in4_id_job_step_run;

				-- set flag job step ready
				SET @__in1_flg_job_step_ready = 1;

				--print @__bit_flg_job_step_ready;

			END

		 COMMIT TRANSACTION;
	END TRY
	/**
	 * ERROR HANDLING
	 * ****************************************
	 */
	BEGIN CATCH	
		/**
		 * Test XACT_STATE for 0, 1, or -1.
		 * If 1, the transaction is committable.
		 * If -1, the transaction is uncommittable and should 
		 *     be rolled back.
		 * XACT_STATE = 0 means there is no transaction and
		 *     a commit or rollback operation would generate an error.
		 */

		-- Test whether the transaction is uncommittable.
		IF (XACT_STATE()) <> 0 BEGIN				
			ROLLBACK TRANSACTION;				
		END;

		THROW;
	END CATCH

END
