﻿CREATE TABLE [ctl].[job_step] (
    [in4_id_job_step]     INT            IDENTITY (1, 1) NOT NULL,
    [in4_id_job]          INT            NOT NULL,
    [vcr_nm_job_step]     VARCHAR (255)  NOT NULL,
    [vcr_nm_etl_package]  VARCHAR (512)  NOT NULL,
    [bit_flg_enabled]     BIT            DEFAULT ((0)) NOT NULL,
    [vcr_txt_description] VARCHAR (1000) NULL,
    PRIMARY KEY CLUSTERED ([in4_id_job_step] ASC),
    FOREIGN KEY ([in4_id_job]) REFERENCES [ctl].[job] ([in4_id_job]),
    UNIQUE NONCLUSTERED ([vcr_nm_etl_package] ASC),
    UNIQUE NONCLUSTERED ([vcr_nm_job_step] ASC)
);

