﻿CREATE TABLE [ctl].[job] (
    [in4_id_job]          INT            IDENTITY (1, 1) NOT NULL,
    [vcr_nm_job]          VARCHAR (255)  NOT NULL,
    [bit_flg_enabled]     BIT            DEFAULT ((0)) NOT NULL,
    [vcr_txt_description] VARCHAR (1000) NULL,
    PRIMARY KEY CLUSTERED ([in4_id_job] ASC),
    UNIQUE NONCLUSTERED ([vcr_nm_job] ASC)
);

