﻿CREATE TABLE [ctl].[job_run] (
    [in4_id_job_run] INT      IDENTITY (1, 1) NOT NULL,
    [in4_id_job]     INT      NOT NULL,
    [dtm_created]    DATETIME DEFAULT (getdate()) NOT NULL,
    [dtm_updated]    DATETIME DEFAULT (getdate()) NOT NULL,
    [dtm_start]      DATETIME DEFAULT (getdate()) NOT NULL,
    [dtm_end]        DATETIME NULL,
    [in1_cde_status] TINYINT  DEFAULT ((1)) NOT NULL,
    PRIMARY KEY CLUSTERED ([in4_id_job_run] ASC),
    FOREIGN KEY ([in4_id_job]) REFERENCES [ctl].[job] ([in4_id_job])
);

