﻿CREATE TABLE [ctl].[job_step_run] (
    [in4_id_job_step_run]       INT            IDENTITY (1, 1) NOT NULL,
    [in4_id_job_run]            INT            NOT NULL,
    [in4_id_job_step]           INT            NOT NULL,
    [dtm_start]                 DATETIME       NULL,
    [dtm_end]                   DATETIME       NULL,
    [in1_cde_status]            TINYINT        DEFAULT ((1)) NOT NULL,
    [in4_num_rows_selected]     INT            DEFAULT ((0)) NOT NULL,
    [in4_num_rows_inserted]     INT            DEFAULT ((0)) NOT NULL,
    [in4_num_rows_updated]      INT            DEFAULT ((0)) NOT NULL,
    [in4_num_rows_deleted]      INT            DEFAULT ((0)) NOT NULL,
    [in4_num_rows_discarded]    INT            DEFAULT ((0)) NOT NULL,
    [in4_cde_error]             INT            DEFAULT ((0)) NOT NULL,
    [vcr_txt_error_description] VARCHAR (4000) NULL,
    PRIMARY KEY CLUSTERED ([in4_id_job_step_run] ASC),
    FOREIGN KEY ([in4_id_job_run]) REFERENCES [ctl].[job_run] ([in4_id_job_run]),
    FOREIGN KEY ([in4_id_job_step]) REFERENCES [ctl].[job_step] ([in4_id_job_step])
);

